const fs = require('fs');
const path = require('path');

// Read version and startYear dynamically from package.json
const packageJson = require('./package.json');
const version = packageJson.version;
const currentYear = new Date().getFullYear();
const startYear = parseInt(packageJson.startYear) || currentYear;
const yearRange = currentYear > startYear ? `${startYear}-${currentYear}` : `${startYear}`;

const copyrightReplace = `Copyright ${yearRange} by`;
const apiReplace = `&copy; ${yearRange}`;

const copyrightRegex = new RegExp(`Copyright ${startYear}(-\\d{4})? by`, 'g');
const apiRegex = new RegExp(`&copy; ${startYear}(-\\d{4})?`, 'g');

// Helper function to replace content inside a file
function replaceInFile(filePath, regex, replacement) {
    const fullPath = path.resolve(__dirname, filePath);
    if (!fs.existsSync(fullPath)) {
        console.warn(`⚠ File not found: ${filePath}`);
        return;
    }
    const content = fs.readFileSync(fullPath, 'utf8');
    const updatedContent = content.replace(regex, replacement);
    fs.writeFileSync(fullPath, updatedContent, 'utf8');
    console.log(`✓ Updated: ${filePath}`);
}

// Helper function to copy a file
function copyFile(sourcePath, targetPath) {
    const fullSource = path.resolve(__dirname, sourcePath);
    const fullTarget = path.resolve(__dirname, targetPath);

    if (!fs.existsSync(fullSource)) {
        console.warn(`⚠ Source file not found for copy: ${sourcePath}`);
        return;
    }

    // Ensure the target directory exists before copying
    const targetDir = path.dirname(fullTarget);
    if (!fs.existsSync(targetDir)) {
        fs.mkdirSync(targetDir, {recursive: true});
    }

    fs.copyFileSync(fullSource, fullTarget);
    console.log(`✓ Copied: ${sourcePath} -> ${targetPath}`);
}

let parts = version.split('-');
let versionNumber = parts[0];
let versionRelease = parts[1] || 'pl';
let versionFull = versionNumber + '-' + versionRelease;

console.log(`Starting bump for version ${versionFull} with daterange: ${yearRange})...`);

const copyrightFiles = [
    'core/components/bettermediabrowser/model/bettermediabrowser/bettermediabrowser.class.php',
    'core/components/bettermediabrowser/src/BetterMediaBrowser.php',
    'core/components/bettermediabrowser/docs/readme.md',
    'README.md',
];
copyrightFiles.forEach(file => {
    replaceInFile(file, copyrightRegex, copyrightReplace);
});

replaceInFile(
    '_build/build.transport.php',
    /PKG_VERSION = '\d+\.\d+\.\d+-?[0-9a-z]*'/ig,
    `PKG_VERSION = '${versionNumber}'`
);

replaceInFile(
    '_build/build.transport.php',
    /PKG_RELEASE = '.*?'/ig,
    `PKG_RELEASE = '${versionRelease}'`
);

replaceInFile(
    'core/components/bettermediabrowser/src/BetterMediaBrowser.php',
    /version = '\d+\.\d+\.\d+-?[0-9a-z]*'/ig,
    `version = '${versionFull}'`
);

// 3. bumpApi
replaceInFile(
    'assets/components/bettermediabrowser/js/mgr/helper/api.js',
    apiRegex,
    apiReplace
);

// 4. bumpComposer
replaceInFile(
    'core/components/bettermediabrowser/composer.json',
    /"version": "\d+\.\d+\.\d+-?[0-9a-z]*"/ig,
    `"version": "${versionFull}"`
);

const copyFiles = [
    ['README.md', 'core/components/bettermediabrowser/docs/readme.md'],
    ['LICENSE.md', 'core/components/bettermediabrowser/docs/license.md'],
    ['CHANGELOG.md', 'core/components/bettermediabrowser/docs/changelog.md']
];
copyFiles.forEach(([source, destination]) => {
    if (source && destination) {
        copyFile(source, destination);
    } else {
        console.warn('⚠ copyFiles: Invalid file pair detected.');
    }
});

console.log('Done!');
