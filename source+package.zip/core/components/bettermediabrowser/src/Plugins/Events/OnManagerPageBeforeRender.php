<?php
/**
 * @package bettermediabrowser
 * @subpackage plugin
 */

namespace Visions\BetterMediaBrowser\Plugins\Events;

use Visions\BetterMediaBrowser\Plugins\Plugin;

class OnManagerPageBeforeRender extends Plugin
{
    public function process()
    {
        if ($this->modx->user && $this->modx->user->hasSessionContext('mgr')) {
            $cssUrl = $this->bettermediabrowser->getOption('cssUrl') . 'mgr/';
            $jsUrl = $this->bettermediabrowser->getOption('jsUrl') . 'mgr/';

            $this->modx->controller->addLexiconTopic('bettermediabrowser:default');

            $this->modx->controller->addJavascript($jsUrl . 'bettermediabrowser.js?v=v' . $this->bettermediabrowser->version);
            $this->modx->controller->addHtml('<script type="text/javascript">
        Ext.onReady(function() {
            BetterMediaBrowser.config = ' . json_encode($this->bettermediabrowser->options, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . ';
        });
        </script>');
            $this->modx->controller->addJavascript($jsUrl . 'helper/api.js?v=v' . $this->bettermediabrowser->version);
            $this->modx->controller->addCss($cssUrl . 'bettermediabrowser.css?v=v' . $this->bettermediabrowser->version);
        }
    }
}
