# Testplan – BetterMediaBrowser 1.3.9

## 1. Installation / Regression

- Manager ohne PHP-/JS-Fehler öffnen ✅
- `bettermediabrowser.enabled = 0` deaktiviert Zusatzfunktionen nach Reload ✅
- `bettermediabrowser.search_enabled = 0` entfernt nur die Suche nach Reload ✅
- `bettermediabrowser.drag_drop_enabled = 0` entfernt nur die Suche nach Reload ✅

## 2. Drag'n'Drop

- Datei in anderem Ordner verschieben ✅
- gleicher Ordner wird abgelehnt ✅
- Root als Ziel testen ✅
- Medienquelle während/zwischen Aktionen wechseln ❓
- User ohne `directory_update` testen ❓
- Mehrere Dateien per Ctrl/Cmd bzw. Shift markieren, eine **markierte** Datei auf einen anderen Ordner ziehen -> alle markierten Dateien werden verschoben ✅
- Bei Mehrfachauswahl eine **nicht markierte** Datei ziehen -> nur diese eine Datei wird verschoben ✅
- Mehrfachauswahl in denselben Ordner ziehen -> keine Datei wird verschoben ✅
- Zielordner mit Namenskollision bei einer Datei testen -> Batch stoppt sauber, Ansicht wird aktualisiert und Teilverschiebung wird angezeigt ✅
- Nach erfolgreichem Mehrfach-Verschieben Quell- und Zielordner im Baum sowie Dateiansicht prüfen ✅

## 3. Suche

- Such-Icon im normalen Media Browser sichtbar ✅
- Such-Icon im Browser-Modal aus Bild-/Datei-TV sichtbar ✅
- leere Suche / 1 Zeichen bei Default-Minimum 2 -> kein Vollscan / keine Treffer ✅
- Dateiname mit Gross-/Kleinschreibung suchen ✅
- Umlaute und Sonderzeichen im Dateinamen testen ✅
- Treffer anklicken: Suchfenster schliesst, Trefferordner wird geladen, Datei markiert, richtige URL steht im Pfadfeld (ist gleich der URL, wenn die Datei angeklickt ist) ✅
- Doppelklick auf Treffer identisch testen ✅
- Treffer in einem tief verschachtelten, im Baum noch nicht aufgeklappten Ordner öffnen: linker Verzeichnisbaum muss bis zum Zielordner expandieren und diesen auswählen. ✅
- Pagination bei > 5 Treffern ✅
- `allowedFileTypes` in einem eingeschränkten Browser testen ✅

## 4. Permissions

- User ohne `file_list`: Suchbutton clientseitig nicht anbieten (wenn `MODx.perm` verfügbar) und direkter Connector-Request serverseitig verweigern ❓
- Media-Source-Policy ohne `list`: Search-Processor verweigert Zugriff ❓
- User mit Zugriff auf Source A, ohne Zugriff auf Source B ❓

## 5. Dynamische Medienquelle

- Suche in Source A durchführen ✅
- im Browser auf Source B wechseln und neue Suche öffnen -> nur Source B ✅
- während geöffnetem Suchfenster Source wechseln -> Treffer darf nicht in die andere Source navigieren ✅

## 6. Medienquelles

- lokale File System Source ✅
- S3, falls im Portfolio eingesetzt ❓
- FTP/Custom Source, falls eingesetzt ❓

Die Suche nutzt `getContainerList()`. Custom Sources müssen diese Methode sinnvoll implementieren. ❓

## 7. Langzeittest

- viele Media-Browser-Modals öffnen/schliessen ❓
- Suchfenster wiederholt öffnen/schliessen ❓
- Drag'n'Drop und Suche abwechselnd verwenden ❓
- Browser-Konsole und MODX Error Log auf neue Warnungen/Leaks prüfen ✅

## Suche – Regression 1.2.2

- Such-Icon erscheint links direkt nach dem Upload-Icon und nicht mehr in der rechten Filter-/Sortier-Toolbar. ✅
- MODX 2.8.x: Suchfenster verwendet dieselbe Sans-Serif-Schrift wie der Manager. ✅
- MODX 3.x: Suchfenster verwendet dieselbe Sans-Serif-Schrift wie der Manager. ✅
- JPG/PNG/WebP/SVG-Treffer zeigen eine Vorschau, sofern die Medienquelle eine Browser-Vorschau bereitstellt. ✅
- Source im Media-Source-Combo wechseln, Suche öffnen und prüfen, dass nur die neu aktive Source durchsucht wird. ✅
- Search-Request ohne `source` muss fehlschlagen/keine Daten liefern. ❓
- Benutzer ohne `file_list` sieht keine Suche bzw. erhält serverseitig keine Suchresultate. ❓

## Suche – Regression 1.2.4

- Der Button «Suchen» im Suchdialog zeigt das MODX-Suchsymbol ohne Ersatzzeichen/Kästchen und der Buttontext bleibt im normalen Manager-Font. ✅
- Das Suchsymbol in der linken Medienbaum-Toolbar wird weiterhin korrekt dargestellt. ✅

## Suche – Regression 1.2.4

- Linkes Suchsymbol neben Upload ist als Lupe sichtbar, nicht als Quadrat. ✅
- Im Suchfenster ist vor «Suchen» eine Lupe sichtbar, ohne Quadrat/Glyph-Fehler. ✅
- Buttontext nutzt die normale MODX-Manager-Schrift. ✅
- MODX 2.8.x und MODX 3.x separat testen. ✅

## SVG-Suchsymbol – Regression 1.2.4

- Linkes Suchsymbol wird direkt neben Upload sichtbar dargestellt. ✅
- Suchbutton im Suchfenster zeigt dasselbe Lupen-SVG ohne Kästchen/Glyphenfehler. ✅
- Buttontext «Suchen» bleibt im normalen MODX-Manager-Font. ✅

## Mehrfachauswahl / Kontextmenü / Batch Download / Batch Delete
- Bei zwei oder mehr markierten Dateien zeigt der Rechtsklick nur «Dateien herunterladen» und «Dateien löschen». ✅
- «Datei umbenennen» und «Sichtbarkeit festlegen» dürfen bei Mehrfachauswahl nicht erscheinen. ✅
- «Dateien herunterladen» startet für jede markierte Datei genau einen Download; keine nicht markierte Datei darf heruntergeladen werden. ✅
- Browser-Verhalten bei mehreren automatischen Downloads prüfen (ggf. einmalige Browser-Freigabe für mehrere Downloads). ✅
- Bei fehlender Download-Berechtigung darf die Sammelaktion nicht angeboten werden bzw. muss serverseitig abgelehnt werden.

- MODX 2.8.x: Zwei oder mehr Dateien mit Ctrl/Cmd auswählen, Rechtsklick auf eine der markierten Dateien, Löschen ausführen. ✅
- Beim Rechtsklick auf eine bereits markierte Datei müssen **alle** zuvor markierten Dateien sichtbar ausgewählt bleiben. ✅
- MODX 3.x: Dasselbe Verhalten mit der bereits nativen Mehrfachauswahl prüfen. ✅
- Prüfen, dass nur die tatsächlich markierten Dateien gelöscht werden. ✅
- Rechtsklick auf eine nicht markierte Datei darf trotz anderer Mehrfachauswahl nur das native Einzel-Löschen auslösen. ✅
- Abbruch im Bestätigungsdialog darf keine Datei löschen. ✅
- Fehlende `file_remove`-Berechtigung muss serverseitig weiterhin abgelehnt werden.
- Nach erfolgreichem Batch Delete werden Browseransicht und Verzeichnisbaum genau einmal aktualisiert. ✅

## Zuletzt verwendeter Ordner

- Unterordner öffnen, Medienbrowser schliessen und erneut öffnen: derselbe Ordner wird über den MODX-`Ext.state.Provider` wiederhergestellt. ✅
- Pro Media Source getrennten letzten Ordner prüfen. ❌
- Wechsel der Media Source darf den gespeicherten Ordner der Zielquelle nicht durch `/` überschreiben. ❓
- Explizites `openTo` eines TVs muss Vorrang vor dem gespeicherten Ordner haben. ❓
- Navigation auf Root soll den gespeicherten Ordner für diese Media Source zurücksetzen. ❌
- Neuen Browser-Tab und neue Manager-Session prüfen: Verhalten folgt dem von MODX konfigurierten `Ext.state.Provider`. ❓
