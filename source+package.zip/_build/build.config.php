<?php
/**
 * Copy to build.config.php and adjust the path to the MODX core directory.
 */
require(dirname(__DIR__, 3) . '/config.core.php');
