<?php
/**
 * Default Lexicon Entries for BetterMediaBrowser
 *
 * @package bettermediabrowser
 * @subpackage lexicon
 */

$_lang['bettermediabrowser'] = 'BetterMediaBrowser';
$_lang['bettermediabrowser.attention'] = 'Achtung';
$_lang['bettermediabrowser.delete_selected'] = 'Dateien löschen';
$_lang['bettermediabrowser.download_selected'] = 'Dateien herunterladen';
$_lang['bettermediabrowser.error_cache_clear'] = 'Der BetterMediaBrowser-Cache konnte nicht geleert werden.';
$_lang['bettermediabrowser.error_media_source_changed'] = 'Die Medienquelle wurde seit der Suche geändert. Bitte öffnen Sie die Suche erneut.';
$_lang['bettermediabrowser.error_not_available'] = 'Nicht verfügbar';
$_lang['bettermediabrowser.error_search'] = 'Die Suche konnte nicht abgeschlossen werden.';
$_lang['bettermediabrowser.error_search_disabled'] = 'Die Dateisuche ist deaktiviert.';
$_lang['bettermediabrowser.error_search_timeout'] = 'Die Suche hat zu lange gedauert. Umfangreiche Ordner können in den Systemeinstellungen von der Suche ausgeschlossen werden.';
$_lang['bettermediabrowser.files_empty'] = 'Keine Dateien gefunden!';
$_lang['bettermediabrowser.menu_clear_cache'] = 'Medien-Browser-Cache leeren';
$_lang['bettermediabrowser.menu_clear_cache_desc'] = 'Leert die Dateisuch-Indizes und die zwischengespeicherten Ordnerlisten aller Medienquellen.';
$_lang['bettermediabrowser.msg_cache_cleared'] = 'Der BetterMediaBrowser-Cache wurde geleert.';
$_lang['bettermediabrowser.msg_download_not_possible'] = 'Die ausgewählten Dateien konnten nicht heruntergeladen werden.';
$_lang['bettermediabrowser.msg_file_exists'] = 'Die Datei befindet sich bereits in diesem Ordner.';
$_lang['bettermediabrowser.msg_file_moved'] = '"[[+file]]" wurde nach "[[+folder]]" verschoben.';
$_lang['bettermediabrowser.msg_files_download_partial'] = '[[+count]] von [[+total]] Downloads wurden gestartet. Der Vorgang wurde wegen eines Fehlers abgebrochen.';
$_lang['bettermediabrowser.msg_files_download_started'] = '[[+count]] Downloads gestartet.';
$_lang['bettermediabrowser.msg_files_move_partial'] = '[[+count]] von [[+total]] Dateien wurden verschoben. Der Vorgang wurde wegen eines Fehlers abgebrochen.';
$_lang['bettermediabrowser.msg_files_moved'] = '[[+count]] ausgewählte Dateien wurden nach "[[+folder]]" verschoben.';
$_lang['bettermediabrowser.msg_files_removed'] = '[[+count]] ausgewählte Dateien wurden gelöscht.';
$_lang['bettermediabrowser.msg_move_not_allowed'] = 'Das Verschieben zwischen unterschiedlichen Medienquellen ist aus Sicherheitsgründen nicht erlaubt.';
$_lang['bettermediabrowser.msg_move_not_possible'] = 'Die Datei konnte nicht verschoben werden.';
$_lang['bettermediabrowser.msg_target_not_allowed'] = 'Dieses Ziel kann nicht zum Verschieben verwendet werden.';
$_lang['bettermediabrowser.msg_timeout'] = 'Der Verschiebevorgang hat zu lange gedauert. Die Ansicht wurde aktualisiert. Bitte prüfen Sie, ob die Datei verschoben wurde.';
$_lang['bettermediabrowser.not_allowed'] = 'Nicht erlaubt';
$_lang['bettermediabrowser.open_in_browser'] = 'Im MODX-Browser öffnen';
$_lang['bettermediabrowser.remove_selected_confirm'] = '[[+count]] ausgewählte Dateien wirklich löschen?';
$_lang['bettermediabrowser.search_filename'] = 'Dateiname suchen …';
$_lang['bettermediabrowser.search_files'] = 'Dateien suchen';
$_lang['bettermediabrowser.source_type'] = 'BetterMediaSource';
$_lang['bettermediabrowser.source_type_desc'] = 'Wie die Dateisystem-Medienquelle, speichert aber die Ordnerlisten des Medien-Browsers zwischen und leert den BetterMediaBrowser-Cache nach jeder Dateiänderung.';
$_lang['bettermediabrowser.timeout'] = 'Zeitüberschreitung';
