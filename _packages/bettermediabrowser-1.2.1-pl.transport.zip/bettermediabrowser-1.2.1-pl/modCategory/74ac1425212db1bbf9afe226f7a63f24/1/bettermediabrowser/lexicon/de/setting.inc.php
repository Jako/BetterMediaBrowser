<?php
/**
 * Setting Lexicon Entries for BetterMediaBrowser
 *
 * @package bettermediabrowser
 * @subpackage lexicon
 */

$_lang['area_mediasource'] = 'Medienquelle';
$_lang['area_search'] = 'Suche';
$_lang['setting_bettermediabrowser.debug'] = 'Debug';
$_lang['setting_bettermediabrowser.debug_desc'] = 'Debug-Informationen im MODX Fehlerprotokoll ausgeben.';
$_lang['setting_bettermediabrowser.drag_drop_enabled'] = 'Drag & Drop aktivieren';
$_lang['setting_bettermediabrowser.drag_drop_enabled_desc'] = 'Drag & Drop für Dateien im MODX Browser aktivieren.';
$_lang['setting_bettermediabrowser.enabled'] = 'Aktiviert';
$_lang['setting_bettermediabrowser.enabled_desc'] = 'Die BetterMediaBrowser-Erweiterung aktivieren.';
$_lang['setting_bettermediabrowser.excluded_folders'] = 'Verzeichnisse ausschließen';
$_lang['setting_bettermediabrowser.excluded_folders_desc'] = 'Kommaseparierte Liste von Ordnern, die vom Suchergebnis ausgeschlossen werden sollen.';
$_lang['setting_bettermediabrowser.list_cache_lifetime'] = 'Lebensdauer des Listen-Caches';
$_lang['setting_bettermediabrowser.list_cache_lifetime_desc'] = 'Sekunden, die die Medienquelle „BetterMediaSource“ die Ordnerlisten des Medien-Browsers zwischenspeichert. Außerhalb von MODX hinzugefügte, gelöschte oder umbenannte Dateien werden sofort angezeigt, außerhalb von MODX ersetzte Dateien nach dieser Zeit. 0 deaktiviert den Cache.';
$_lang['setting_bettermediabrowser.remember_last_folder'] = 'Letzten Ordner merken';
$_lang['setting_bettermediabrowser.remember_last_folder_desc'] = 'Den zuletzt geöffneten Ordner jeder Medienquelle im MODX Browser merken und wieder öffnen.';
$_lang['setting_bettermediabrowser.search_enabled'] = 'Suche aktivieren';
$_lang['setting_bettermediabrowser.search_enabled_desc'] = 'Die BetterMediaBrowser-Dateisuche aktivieren.';
$_lang['setting_bettermediabrowser.search_max_results'] = 'Max. Ergebnisse';
$_lang['setting_bettermediabrowser.search_max_results_desc'] = 'Maximale Anzahl von Dateien in den Suchergebnissen.';
$_lang['setting_bettermediabrowser.search_min_length'] = 'Mindestlänge';
$_lang['setting_bettermediabrowser.search_min_length_desc'] = 'Mindestlänge des Suchbegriffs, bevor die Suche ausgeführt wird.';
