<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS
',
    'readme' => '# BetterMediaBrowser

**BetterMediaBrowser** extends the MODX browser with drag-and-drop functionality
for moving one or more files within the tree, deleting/downloading multiple
files, and searching for files in the currently active media source. It also
installs the BetterMediaSource media source type with faster and cached folder
lists in the media browser.

## Features

- Move files directly from the right-hand media view to a folder in the left-hand tree
- Move multiple selected files to another folder at once using drag-and-drop
- Select multiple files using Ctrl/Cmd or Shift and download or delete them all at once
- Remember the most recently used subfolders of a media source and restore them the next time the source is opened (can be disabled with a system setting)
- Keep the toolbar and the media source selector of the directory tree visible while scrolling the tree
- Search using a search icon in the media source’s toolbar
- Fast searches with a cached file index per media source, which is cleared automatically on file changes and with the Clear media browser cache menu entry
- Display search results with thumbnails for images, file icons for other files and relative paths
- A search hit opens the target folder in the file view, opens the folder in the directory tree, and sets the path when a file is selected
- BetterMediaSource media source type with faster and cached folder lists in the media browser
- Compatible with MODX 2.8.x and 3.x

## BetterMediaSource

BetterMediaBrowser installs the media source type _BetterMediaSource_. It works
like the file system media source with the same properties, permissions and
policies, and adds:

- **Faster folder lists** (MODX 3): The media browser tree and file view are built up to 30 times faster.
- **Cached folder lists**: The media browser tree and file view are cached per user, context and manager language. The lifetime is set with the `bettermediabrowser.list_cache_lifetime` system setting.
- **Cache clearing in the media source**: The cache of the media source is cleared after each file change in the media source itself, even if the BetterMediaBrowser plugin is disabled or a file is changed by other code that does not fire the file manager events.

To use it, change the type of an existing file system media source to
_BetterMediaSource_ or create a new media source of this type. When
BetterMediaBrowser is uninstalled, all BetterMediaSource media sources are
converted back to file system media sources.

## Security

The search performs the following checks on the server side:

- The `file_list` manager permission
- The `list` media source policy
- The working context of the requested media source

Drag-and-drop in the MODX browser uses the *Core Directory Sort Processor* with the current user\'s permissions.

Deleting and Downloading multiple files in the MODX browser use the *Core Remove Processor* or the *Core Download Processor* with the current user\'s permissions.

## Installation

MODX Package Management

## System Settings

_BetterMediaBrowser_ contains some _system settings_ in the `bettermediabrowser` namespace.

| Key                                     | Name                 | Description                                                                                                          | Default                                          |
|-----------------------------------------|----------------------|----------------------------------------------------------------------------------------------------------------------|--------------------------------------------------|
| bettermediabrowser.debug                | Debug                | Log debug information in the MODX error log.                                                                         | No                                               |
| bettermediabrowser.enabled              | Enabled              | Enable the BetterMediaBrowser extension.                                                                             | Yes                                              |
| bettermediabrowser.drag_drop_enabled    | Enable Drag & Drop   | Enable drag-and-drop for files in the MODX Browser.                                                                  | Yes                                              |
| bettermediabrowser.search_enabled       | Enable Search        | Enable the BetterMediaBrowser file search.                                                                           | Yes                                              |
| bettermediabrowser.remember_last_folder | Remember Last Folder | Remember the last opened folder of each media source in the MODX Browser and open it again.                          | Yes                                              |
| bettermediabrowser.search_min_length    | Min Length           | Minimum length of the search string before a search is executed.                                                     | 2                                                |
| bettermediabrowser.search_max_results   | Max Results          | Maximum count of files in the search results.                                                                        | 500                                              |
| bettermediabrowser.excluded_folders     | Excluded Folders     | Comma-separated list of folders to be excluded from the search results.                                              | `.*/,_*/,core/,components/,connectors/,manager/` |
| bettermediabrowser.list_cache_lifetime  | List Cache Lifetime  | Seconds, that the BetterMediaSource media source caches the folder lists of the media browser. 0 disables the cache. | 300                                              |

## License

GPL-2.0-or-later

Copyright 2026 visions.ch gmbh & Treehill Studio
',
    'changelog' => '# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## 1.2.1 – 2026-11-18

### Added

- Disable remembering the last opened folder of a media source with the remember_last_folder system setting

### Fixed

- Fatal error "Class modFileMediaSource_mysql not found" in MODX 2, when a file system media source is created after a BetterMediaSource

## 1.2.0 – 2026-11-04

### Added

- BetterMediaSource media source type, that extends the file system media source and clears its file search cache on each file change
- Build the folder lists of the media browser up to 30 times faster in the BetterMediaSource media source in MODX 3
- Search while typing in the file search window, if the media source has a file index
- Cache the folder lists of the media browser in the BetterMediaSource media source (list_cache_lifetime system setting)
- Clear media browser cache menu entry below the Clear Cache menu entry, that clears the BetterMediaBrowser cache of all media sources

### Changed

- Don\'t clear the BetterMediaBrowser cache when the MODX cache is cleared, use the Clear media browser cache menu entry instead

### Fixed

- Send only one request per search in the file search window
- Clear the search cache of the target media source, when a file is moved to another media source
- Rebuild the search index, when the properties of a media source are changed
- Don\'t expose server paths in the manager configuration of BetterMediaBrowser
- Remove an unused script file

## 1.1.0 – 2026-10-25

### Added

- Cache a file index per media source for faster searches
- Clear the search cache on file changes and when the MODX cache is cleared
- Keep the toolbar and the media source selector of the media browser tree visible while scrolling the tree
- Dutch, French and Russian translations

### Changed

- Faster scanning of local and MODX 3 media sources
- Sort the search results before limiting them
- Show a file icon instead of a thumbnail for files that are not images in the file search window

### Fixed

- Show an error message for all fatal errors in the file search, without exposing server paths
- Use the search_enabled system setting to enable the file search
- Use the enabled system setting to enable BetterMediaBrowser
- Use the working context of the media browser for the thumbnails in the file search window

## 1.0.3 – 2026-10-21

### Added

- Use the default MODX thumbnail generation in the file search window

## 1.0.2 – 2026-10-19

### Added

- The cache of the search list uses also the file-type filter
- An empty search result is also cached in the search list cache

### Fixed

- Match excluded folders from the media source root, so that folders with the same name in subfolders are not excluded anymore

## 1.0.1 – 2026-10-10

### Added

- Add an error message, when a timeout occurs in the file search window

## 1.0.0 – 2026-09-16

### Added

- Initial Version
',
    'setup-options' => 'bettermediabrowser-1.2.1-pl/setup-options.php',
    'requires' => 
    array (
      'php' => '>=7.4',
      'modx' => '>=2.8',
    ),
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '5368b9d22a278dff6b70005870c5d1bf',
      'native_key' => 'bettermediabrowser',
      'filename' => 'modNamespace/56690281b4b2173c0e5c96104af365a5.vehicle',
      'namespace' => 'bettermediabrowser',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '249cabb23128cbc1098055f4b8f9c5f8',
      'native_key' => 'bettermediabrowser.enabled',
      'filename' => 'modSystemSetting/c9efb04be7456b927fc8b27433747002.vehicle',
      'namespace' => 'bettermediabrowser',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3549224bf75317bd0347b7cd1648e17a',
      'native_key' => 'bettermediabrowser.debug',
      'filename' => 'modSystemSetting/2c475b3023537bf4bd0673e7bb437510.vehicle',
      'namespace' => 'bettermediabrowser',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53f40a1d2fab4e1c389020a4bd580d15',
      'native_key' => 'bettermediabrowser.drag_drop_enabled',
      'filename' => 'modSystemSetting/dd21cfed9f12082d4355a06874f66f47.vehicle',
      'namespace' => 'bettermediabrowser',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a41d266bfacf796d3e860b0ab793e9d',
      'native_key' => 'bettermediabrowser.search_enabled',
      'filename' => 'modSystemSetting/ff18abb5745830289ef99122be53e019.vehicle',
      'namespace' => 'bettermediabrowser',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2e95d7f0e7b3ee72f230902d7fe09537',
      'native_key' => 'bettermediabrowser.remember_last_folder',
      'filename' => 'modSystemSetting/9aefbd9e8a436193588a1423f2dd1f78.vehicle',
      'namespace' => 'bettermediabrowser',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a0404994a132155ec2b0d3c40358a6bb',
      'native_key' => 'bettermediabrowser.search_min_length',
      'filename' => 'modSystemSetting/cb06448f500a498f85102d732156053d.vehicle',
      'namespace' => 'bettermediabrowser',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '69bdce4ed51a5ce5ccc0325a5138bf03',
      'native_key' => 'bettermediabrowser.search_max_results',
      'filename' => 'modSystemSetting/d7718df66e070a755953c9cf912dd0b3.vehicle',
      'namespace' => 'bettermediabrowser',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '21a77f7997a84c5a92bdab685086e185',
      'native_key' => 'bettermediabrowser.excluded_folders',
      'filename' => 'modSystemSetting/360615fc6a1b85f001bc8efc1b441d80.vehicle',
      'namespace' => 'bettermediabrowser',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4306a068149c0714dcf3421dbfcec92c',
      'native_key' => 'bettermediabrowser.list_cache_lifetime',
      'filename' => 'modSystemSetting/1244e6f4d30d009f4bfff46f76b98fcb.vehicle',
      'namespace' => 'bettermediabrowser',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'c3a0885cf2c952f69658e04d95d11ccb',
      'native_key' => NULL,
      'filename' => 'modCategory/74ac1425212db1bbf9afe226f7a63f24.vehicle',
      'namespace' => 'bettermediabrowser',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '930165708007538e2f2a3d5eda9dca3e',
      'native_key' => 'bettermediabrowser.menu_clear_cache',
      'filename' => 'modMenu/59dbb80615a88e2c1e83afb40a04424e.vehicle',
      'namespace' => 'bettermediabrowser',
    ),
  ),
);