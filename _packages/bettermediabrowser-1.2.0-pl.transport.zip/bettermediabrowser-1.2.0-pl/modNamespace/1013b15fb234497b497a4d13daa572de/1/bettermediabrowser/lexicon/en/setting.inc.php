<?php
/**
 * Setting Lexicon Entries for BetterMediaBrowser
 *
 * @package bettermediabrowser
 * @subpackage lexicon
 */

$_lang['area_mediasource'] = 'Media Source';
$_lang['area_search'] = 'Search';
$_lang['setting_bettermediabrowser.debug'] = 'Debug';
$_lang['setting_bettermediabrowser.debug_desc'] = 'Log debug information in the MODX error log.';
$_lang['setting_bettermediabrowser.drag_drop_enabled'] = 'Enable Drag & Drop';
$_lang['setting_bettermediabrowser.drag_drop_enabled_desc'] = 'Enable Drag & Drop for files in the MODX Browser.';
$_lang['setting_bettermediabrowser.enabled'] = 'Enabled';
$_lang['setting_bettermediabrowser.enabled_desc'] = 'Enable the BetterMediaBrowser extension.';
$_lang['setting_bettermediabrowser.excluded_folders'] = 'Excluded Folders';
$_lang['setting_bettermediabrowser.excluded_folders_desc'] = 'Comma-separated list of folders to be excluded from the search results.';
$_lang['setting_bettermediabrowser.list_cache_lifetime'] = 'List Cache Lifetime';
$_lang['setting_bettermediabrowser.list_cache_lifetime_desc'] = 'Seconds, that the BetterMediaSource media source caches the folder lists of the media browser. Files added, removed or renamed outside of MODX are shown immediately, files replaced outside of MODX after this time. 0 disables the cache.';
$_lang['setting_bettermediabrowser.search_enabled'] = 'Enable Search';
$_lang['setting_bettermediabrowser.search_enabled_desc'] = 'Enable the BetterMediaBrowser file search.';
$_lang['setting_bettermediabrowser.search_max_results'] = 'Max Results';
$_lang['setting_bettermediabrowser.search_max_results_desc'] = 'Maximum count of files in the search results.';
$_lang['setting_bettermediabrowser.search_min_length'] = 'Min Length';
$_lang['setting_bettermediabrowser.search_min_length_desc'] = 'Minimum length of the search string before as search is executed.';
