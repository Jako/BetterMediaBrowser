<?php
/**
 * Default Lexicon Entries for BetterMediaBrowser
 *
 * @package bettermediabrowser
 * @subpackage lexicon
 */

$_lang['bettermediabrowser'] = 'BetterMediaBrowser';
$_lang['bettermediabrowser.attention'] = 'Attention';
$_lang['bettermediabrowser.delete_selected'] = 'Delete files';
$_lang['bettermediabrowser.download_selected'] = 'Download files';
$_lang['bettermediabrowser.error_cache_clear'] = 'Could not clear the BetterMediaBrowser cache.';
$_lang['bettermediabrowser.error_media_source_changed'] = 'The media source changed after the search. Please open the search again.';
$_lang['bettermediabrowser.error_not_available'] = 'Not available';
$_lang['bettermediabrowser.error_search'] = 'The search could not be completed.';
$_lang['bettermediabrowser.error_search_disabled'] = 'The file search is disabled.';
$_lang['bettermediabrowser.error_search_timeout'] = 'The search took too long. Large folders can be excluded from the search in the system settings.';
$_lang['bettermediabrowser.files_empty'] = 'No files found!';
$_lang['bettermediabrowser.menu_clear_cache'] = 'Clear media browser cache';
$_lang['bettermediabrowser.menu_clear_cache_desc'] = 'Clears the file search indexes and the cached folder lists of all media sources.';
$_lang['bettermediabrowser.msg_cache_cleared'] = 'The BetterMediaBrowser cache was cleared.';
$_lang['bettermediabrowser.msg_download_not_possible'] = 'The selected files could not be downloaded.';
$_lang['bettermediabrowser.msg_file_exists'] = 'The file is already in this folder.';
$_lang['bettermediabrowser.msg_file_moved'] = '"[[+file]]" was moved to "[[+folder]]".';
$_lang['bettermediabrowser.msg_files_download_partial'] = '[[+count]] of [[+total]] downloads were started. The operation stopped because of an error.';
$_lang['bettermediabrowser.msg_files_download_started'] = '[[+count]] downloads started.';
$_lang['bettermediabrowser.msg_files_move_partial'] = '[[+count]] of [[+total]] files were moved. The operation stopped because of an error.';
$_lang['bettermediabrowser.msg_files_moved'] = '[[+count]] selected files were moved to "[[+folder]]".';
$_lang['bettermediabrowser.msg_files_removed'] = '[[+count]] selected files were deleted.';
$_lang['bettermediabrowser.msg_move_not_allowed'] = 'For security reasons, moving files between different media sources is not permitted.';
$_lang['bettermediabrowser.msg_move_not_possible'] = 'The file could not be moved.';
$_lang['bettermediabrowser.msg_target_not_allowed'] = 'This target cannot be used for moving files.';
$_lang['bettermediabrowser.msg_timeout'] = 'The move request took too long. The view was refreshed. Please verify whether the file was moved.';
$_lang['bettermediabrowser.not_allowed'] = 'Not allowed';
$_lang['bettermediabrowser.open_in_browser'] = 'Open in MODX Browser';
$_lang['bettermediabrowser.remove_selected_confirm'] = 'Really delete [[+count]] selected files?';
$_lang['bettermediabrowser.search_filename'] = 'Search filename …';
$_lang['bettermediabrowser.search_files'] = 'Search Files';
$_lang['bettermediabrowser.source_type'] = 'BetterMediaSource';
$_lang['bettermediabrowser.source_type_desc'] = 'Like the file system media source, but caches the folder lists of the media browser and clears the BetterMediaBrowser cache after each file change.';
$_lang['bettermediabrowser.timeout'] = 'Timeout';
