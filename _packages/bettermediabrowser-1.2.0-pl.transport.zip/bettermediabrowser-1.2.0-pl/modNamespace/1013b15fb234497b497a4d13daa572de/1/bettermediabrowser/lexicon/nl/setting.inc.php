<?php
/**
 * Setting Lexicon Entries for BetterMediaBrowser
 *
 * @package bettermediabrowser
 * @subpackage lexicon
 */

$_lang['area_mediasource'] = 'Mediabron';
$_lang['area_search'] = 'Zoeken';
$_lang['setting_bettermediabrowser.debug'] = 'Debug';
$_lang['setting_bettermediabrowser.debug_desc'] = 'Debuginformatie in het MODX-foutenlogboek opslaan.';
$_lang['setting_bettermediabrowser.drag_drop_enabled'] = 'Drag & Drop inschakelen';
$_lang['setting_bettermediabrowser.drag_drop_enabled_desc'] = 'Drag & Drop voor bestanden in de MODX-browser inschakelen.';
$_lang['setting_bettermediabrowser.enabled'] = 'Ingeschakeld';
$_lang['setting_bettermediabrowser.enabled_desc'] = 'De BetterMediaBrowser-extensie inschakelen.';
$_lang['setting_bettermediabrowser.excluded_folders'] = 'Uitgesloten mappen';
$_lang['setting_bettermediabrowser.excluded_folders_desc'] = 'Kommagescheiden lijst van mappen die van de zoekresultaten worden uitgesloten.';
$_lang['setting_bettermediabrowser.list_cache_lifetime'] = 'Levensduur lijstcache';
$_lang['setting_bettermediabrowser.list_cache_lifetime_desc'] = 'Seconden dat de mediabron „BetterMediaSource” de maplijsten van de mediabrowser in de cache bewaart. Buiten MODX toegevoegde, verwijderde of hernoemde bestanden worden direct getoond, buiten MODX vervangen bestanden na deze tijd. 0 schakelt de cache uit.';
$_lang['setting_bettermediabrowser.search_enabled'] = 'Zoeken inschakelen';
$_lang['setting_bettermediabrowser.search_enabled_desc'] = 'De BetterMediaBrowser-bestandszoekfunctie inschakelen.';
$_lang['setting_bettermediabrowser.search_max_results'] = 'Max. resultaten';
$_lang['setting_bettermediabrowser.search_max_results_desc'] = 'Maximaal aantal bestanden in de zoekresultaten.';
$_lang['setting_bettermediabrowser.search_min_length'] = 'Minimale lengte';
$_lang['setting_bettermediabrowser.search_min_length_desc'] = 'Minimale lengte van de zoekterm voordat de zoekopdracht wordt uitgevoerd.';
