<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => false,
    'readme' => '# BetterMediaBrowser

**BetterMediaBrowser** extends the MODX browser with drag-and-drop functionality for moving one or more files within the tree, deleting/downloading multiple files, and searching for files in the currently active media source.

## Features

- Move files directly from the right-hand media view to a folder in the left-hand tree
- Move multiple selected files to another folder at once using drag-and-drop
- Select multiple files using Ctrl/Cmd or Shift and download or delete them all at once
- Remember the most recently used subfolders of a media source and restore them the next time the source is opened
- Search using a search icon in the media source’s toolbar
- Display search results with thumbnails and relative paths
- A search hit opens the target folder in the file view, opens the folder in the directory tree, and sets the path when a file is selected
- Compatible with MODX 2.8.x and 3.x

## Security

The search performs the following checks on the server side:

- The `file_list` manager permission
- The `list` media source policy
- The working context of the requested media source

Drag-and-drop in the MODX browser uses the *Core Directory Sort Processor* with the current user\'s permissions.

Deleting and Downloading multiple files in the MODX browser use the *Core Remove Processor* or the *Core Download Processor* with the current user\'s permissions.

## Installation

MODX Package Management

## System Settings

_BetterMediaBrowser_ contains some _system settings_ in the `bettermediabrowser` namespace.

| Key                                   | Name               | Description                                                             | Default                                      |
|---------------------------------------|--------------------|-------------------------------------------------------------------------|----------------------------------------------|
| bettermediabrowser.debug              | Debug              | Log debug information in the MODX error log.                            | Nein                                         |         
| bettermediabrowser.enabled            | Enabled            | Enable the BetterMediaBrowser extension.                                | Ja                                           |         
| bettermediabrowser.drag_drop_enabled  | Enable Drag & Drop | Enable drag-and-drop for files in the MODX Browser.                     | Ja                                           |         
| bettermediabrowser.search_enabled     | Enable Search      | Enable the BetterMediaBrowser file search.                              | Ja                                           |         
| bettermediabrowser.search_min_length  | Min Length         | Minimum length of the search string before as search is executed.       | 2                                            |         
| bettermediabrowser.search_max_results | Max Results        | Maximum count of files in the search results.                           | 500                                          |         
| bettermediabrowser.excluded_folders   | Excluded Folders   | Comma-separated list of folders to be excluded from the search results. | `.*/,core/,components/,connectors/,manager/` |         

## License

GPL-2.0-or-later

Copyright 2026 visions.ch gmbh & Treehill Studio
',
    'changelog' => '# Changelog

All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## 1.0.0-pl – 2026-09-16

- Initial Version
',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '1d100cb6b54e8a80683d57460db409e9',
      'native_key' => 'bettermediabrowser',
      'filename' => 'modNamespace/fbe3df0f6d72a9fe10eb9cf5ded98929.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '18c9bbf7bf50756ad66849c3dd5c83ca',
      'native_key' => 'bettermediabrowser.enabled',
      'filename' => 'modSystemSetting/08f2b667f314b83f09ade71257bed077.vehicle',
      'namespace' => 'bettermediabrowser',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f032a5d1a3643a054b5a3789326326bb',
      'native_key' => 'bettermediabrowser.debug',
      'filename' => 'modSystemSetting/32419a57258e9151ad9ab4d5d36f9e32.vehicle',
      'namespace' => 'bettermediabrowser',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f95a16d6ffcfb94345c92e44c1a0b584',
      'native_key' => 'bettermediabrowser.drag_drop_enabled',
      'filename' => 'modSystemSetting/e0b734196a14108eb855812c4dd07bf8.vehicle',
      'namespace' => 'bettermediabrowser',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fa9fa3a68165ed7b98d0882b01d8d72b',
      'native_key' => 'bettermediabrowser.search_enabled',
      'filename' => 'modSystemSetting/5741c958ea657b62b16f252f8f516562.vehicle',
      'namespace' => 'bettermediabrowser',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43fc01121f4124cf22bfd0b74b6f3972',
      'native_key' => 'bettermediabrowser.search_min_length',
      'filename' => 'modSystemSetting/e7fe13a8773134d4fb7574b13a258962.vehicle',
      'namespace' => 'bettermediabrowser',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a587fba6fce078d579040b25bc2cfc0',
      'native_key' => 'bettermediabrowser.search_max_results',
      'filename' => 'modSystemSetting/4232f3e91d29ee12373dc85d2c843547.vehicle',
      'namespace' => 'bettermediabrowser',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a6d18592e9978ee6bef524575ad928e',
      'native_key' => 'bettermediabrowser.excluded_folders',
      'filename' => 'modSystemSetting/0b3d1c2c8d10c1ec8dfba84e31edf1c6.vehicle',
      'namespace' => 'bettermediabrowser',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'f84e6b1d674ae4cd0049bcfc90cd41be',
      'native_key' => 1,
      'filename' => 'modCategory/2c514b99085035f4773d472f8cb108b7.vehicle',
      'namespace' => 'bettermediabrowser',
    ),
  ),
);